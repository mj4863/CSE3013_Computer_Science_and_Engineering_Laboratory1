#include <stdio.h>
#include "blackcow.h"

void blackcow() {
	printf("blackcow\n");
}
