void blackcow();
void dog();
void turtle();