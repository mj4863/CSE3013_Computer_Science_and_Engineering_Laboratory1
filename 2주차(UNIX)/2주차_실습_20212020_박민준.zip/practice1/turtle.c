#include <stdio.h>
#include "blackcow.h"

void turtle() {
	printf("turtle\n");
}
