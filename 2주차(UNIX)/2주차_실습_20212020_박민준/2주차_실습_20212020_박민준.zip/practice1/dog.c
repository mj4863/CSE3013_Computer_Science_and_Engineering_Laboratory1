#include <stdio.h>
#include "blackcow.h"

void dog() {
	printf("dog\n");
}
