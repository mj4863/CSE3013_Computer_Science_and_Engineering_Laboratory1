#include <stdio.h>
#include "blackcow.h"

int main(void) {
	dog();
	blackcow();
	turtle();
	
	return 0;
}
